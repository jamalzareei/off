<?php
//includes:
include 'backupDB/dbbackup.php';
backup_tables('localhost','username','password','databaseName','*','khanzadimahdi@gmail.com',true); //set charset utf8
backup_tables('localhost','username','password','databaseName','*','khanzadimahdi@gmail.com'); //use default charset
?>
